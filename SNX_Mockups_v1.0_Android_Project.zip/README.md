# SNX Mockups v1.0

Android mockup studio with an interactive Three.js garment preview.

## v1.0 improvements
- Individual 3D garment silhouettes for tank tops, V-neck tees, long sleeves, polos, hoodies, oversized tees, shorts, sweatshirts, cropped hoodies, suit shirts and jogger sets.
- Garment-specific hoodie hoods and kangaroo pocket, polo/suit placket details, garment seams and fabric fold accents.
- Upload artwork from the Android photo picker and map it onto the 3D garment.
- Garment and scene color controls, front/back view, drag-to-rotate, and 1080px PNG export to Pictures/SNX Mockups.
- Android native image picker and MediaStore save support.

The 3D renderer currently loads Three.js from jsDelivr, so an internet connection is required to open 3D models.

## Build
Open the project in Android Studio or use the repository GitHub Actions workflow.
