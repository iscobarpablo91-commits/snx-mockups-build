# SNX Mockups v0.3

Android WebView mockup studio with an interactive Three.js 3D T-shirt preview. Includes drag-to-rotate viewing, procedural garment shape and collar, fabric fold highlights, color selection, and uploaded artwork mapped onto the front.

The Three.js module loads from jsDelivr, so the first 3D preview requires internet access.
