package com.snx.mockups;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.view.Window;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){super.onCreate(b); WebView w=new WebView(this); w.setBackgroundColor(0xff090a10);
  WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
  w.setWebChromeClient(new WebChromeClient()); w.setWebViewClient(new WebViewClient());
  w.loadUrl("file:///android_asset/index.html"); setContentView(w);
 }
 @Override public void onBackPressed(){super.onBackPressed();}
}
