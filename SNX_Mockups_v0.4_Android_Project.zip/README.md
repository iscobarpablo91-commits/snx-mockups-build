# SNX Mockups v0.4

Android WebView mockup studio with an interactive Three.js 3D garment preview.

## Improvements in v0.4
- More dimensional garment body with softened silhouette and bevels.
- Fabric drape, fold highlights, collar detailing and seam accents.
- Improved studio lighting and material response.
- Front/back controls and rotate controls now drive the actual 3D model.
- Artwork remains mapped to the front of the garment.

The Three.js module loads from jsDelivr, so the first 3D preview requires internet access.

## Build
Open this project in Android Studio, allow Gradle sync, then run the `app` configuration.
