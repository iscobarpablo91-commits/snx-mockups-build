# SNX Mockups v0.2
Android WebView project source + browser prototype.

## Included
- Gallery of 11 garment mockup categories
- Upload PNG/JPG/WebP artwork
- Artwork drag/resize/center controls
- Garment color and scene background controls
- Front/back/both selection and simulated 3D rotation
- PNG export
- Android Studio Gradle project (applicationId `com.snx.mockups`, minSdk 23)

## Build APK
Open this folder in Android Studio with Android Gradle Plugin 8.7.3 and JDK 17, allow Gradle sync, then Build > Build APK(s).

This environment does not include Android SDK/Gradle, so an APK has not been compiled or device-tested here. The garment renderer is a stylized SVG/2.5D preview, not a full physically based 3D engine. No original app assets or payment/license code are included.
