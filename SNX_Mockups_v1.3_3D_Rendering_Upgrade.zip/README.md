# SNX Mockups 1.2 — Android project

Android apparel mockup editor with a Three.js 3D garment preview.

## Build
Requires JDK 17, Android SDK Platform 36 and Gradle 8.11.1.
Run `gradle assembleDebug` for a test APK and `gradle bundleRelease` for the Play upload bundle.

## Play Store signing
A Play Store AAB must be signed. Configure the GitHub Actions repository secrets:
- `SNX_KEYSTORE_BASE64`: base64-encoded upload keystore
- `SNX_KEYSTORE_PASSWORD`
- `SNX_KEY_ALIAS`
- `SNX_KEY_PASSWORD`

Never commit the keystore or its passwords to the repository. If signing secrets are not configured, the workflow's AAB is unsigned and is not uploadable to Play Console.

## Important release notes
- The 3D preview loads Three.js from jsDelivr and requires internet access.
- Publish `docs/PRIVACY_POLICY.md` at a public HTTPS URL and replace the support-email placeholder before submission.
- The store listing draft is in `docs/PLAY_STORE_LISTING.md`.
- Test artwork import, front/back/sleeve placement, rotation, resize, export and app resume on physical devices before production.


## Version 1.3 rendering upgrade
The 3D studio now uses higher-resolution physically based textile materials, woven/bump texture, upgraded lighting and shadow treatment, more detailed collar/hood/pocket construction, and additional top-stitch and drape-fold geometry. This is a visual upgrade to the existing procedural garment model; it is not a scanned garment asset or a physically simulated cloth solver. Validate on physical devices before production.
