# Google Play listing draft

App name: SNX Mockups

Short description (max 80 chars):
Create apparel mockups with interactive 3D garment previews.

Full description:
Design product mockups for your clothing brand with SNX Mockups. Choose from a collection of apparel templates, preview garments in an interactive 3D studio, add your own artwork, adjust placement and size, customize garment colors, and export mockup images to your device.

Features:
- Apparel templates including tees, hoodies, polos, shorts and tracksuits
- Interactive 3D garment preview with front and back views
- Import your own PNG, JPG or WebP artwork
- Place artwork on the front, back or sleeves
- Adjust artwork size and rotation
- Customize garment and scene colors
- Export a 1080px PNG to your device

Notes:
- An internet connection is required to load the 3D preview engine.
- Mockups are generated on your device.
- No account is required.

Before submitting:
- Replace the privacy-policy contact placeholder with a monitored support email.
- Publish docs/PRIVACY_POLICY.md at a public HTTPS URL and enter that URL in Play Console.
- Complete the Data safety form accurately.
- Upload a 512x512 store icon and at least two phone screenshots.
- Complete app access, ads, content rating, target audience, and store listing declarations.
