# SNX Mockups — Privacy Policy

Last updated: 5 November 2026

SNX Mockups lets you preview apparel and place your own artwork on garment mockups.

## Information we collect
SNX Mockups does not require an account and does not operate its own analytics, advertising, or tracking service. Artwork you select is used in the app to render your mockup. The app does not upload your artwork to an SNX server.

## Device permissions and files
The app uses Android's system file picker when you choose an image. When you export a mockup, the app saves the resulting PNG to your device's Pictures/SNX Mockups folder. You control which images you select and export.

## Network access and third parties
The 3D preview loads the Three.js rendering library from jsDelivr (cdn.jsdelivr.net). When the library is requested, your device makes a network request to that content-delivery provider, which may receive standard connection information such as your IP address. The app's 3D preview therefore requires an internet connection. Please review jsDelivr's privacy information for its handling of connection data.

## Data sharing and retention
SNX does not receive or retain the artwork you select through the app. Exported images remain on your device unless you independently share them. We do not sell personal information.

## Children
The app is a general-purpose creative tool and is not designed specifically for children under 13.

## Changes and contact
This policy may be updated when app functionality changes. For privacy questions, contact: [ADD A SUPPORT EMAIL BEFORE PUBLISHING].
